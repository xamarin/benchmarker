SPEC JVM Client version 17 release notes
---------------------------------

Changes to the benchmark harness:

    The pause and gc which you can select is now in between different
benchmarks rather than between runs of a single benchmark. Also, each
time System.gc is invoked by the harness, run finalization is also done
to avoid class references hanging on from one benchmark to the next.

    Smaller untimed runs are interspersed in an autorun sequence
so that the timed executions are not using the same input data
as the previous execution. This is to help avoid uncharacteristic
learning by feedback optimizers. See:
http://pro.specbench.org/private/osg/mail/osgjava/0173.html

New or Significantly Updated Benchmarks:

_200_check
    No longer trying to read system properties. Security violation.
    http://pro.specbench.org/private/osg/mail/osgjava/0153.html
_202_jess
    Updated to latest version 3.2
    Old beta 2.21 is moved to spec/retired directory.
_205_raytrace
    Bug fix to thread handling to avoid unintended class and thread references
    consuming memory from run to run. Don McCauley - IBM
_209_db
    Byte/string conversion made insensitive to line termination character(s)
_211_anagram
    Byte/string conversion made insensitive to line termination character(s)
_227_mtrt
    Inherits bug fix from _205_raytrace
_233_tmix
    This is the same as the _231_tmix benchmark, with the addition of
    Deltablue as an additional subtest workload, and the tests rebalanced
    by Kaivalya Dixit
_237_compress
    Moved to spec/retired at requrest of project leader because
    profile showed most time spent in initialization
_238_mpeg
    Fixes from Kaivalya Dixit and Anirudha Rahatekar. Diff listing in
    benchmark directory README
_239_nih
    Fixes from Kaivalya Dixit and Anirudha Rahatekar. Diff listing in
    benchmark directory README

New tool:

The Config program prints configuration properties to create client
or server property files. SPEC members may provide platform specific
classes to determine additional properties by executing vendor
specific native commands.

This is to aid the benchmarker in the generation of correct client and
server property files, to make it easier to report accurate consistent
information than to report inaccurate or inconsistent configuration
information, and thus to facilitate the process of SPEC review and
results publication.

Usage: java spec.reporter.vendor.Config [-v vendor] [-s server] [-p port] [-S SPECdir]
Create client & server property files to document a configuration
vendor - Specify OS & h/w, e.g. SolarisSparc
server - Name of server where benchmarks are installed.
         Default localhost
         If specified, creates server file instead of client file
port -   Server's http port number. Default 80
         If specified, creates server file instead of client file
SPECdir - Directory where SPEC software is installed, if not the
         current directory.

