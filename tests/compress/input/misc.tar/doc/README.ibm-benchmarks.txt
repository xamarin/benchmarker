java Benchmark candidates:

cst     - java.util.* class file exerciser
Si      - Small Interpreter
anagram - anagram generator
db      - database

Please see "doc" files included with each benchmark.

I have had difficulties with "out of memory" exceptions across different
machines/jvm versions (including -mx & -ms (or excluding in some cases) 
usually remedies); and going to 1.1B (deprecated methods; StreamTokenizer's
switch to buffered input (invalidating InputStream.available() method).  Also,
I've had mixed success running existing .class files on different machines
and have had to recompile in several cases.

With minor mods to the run scripts, I have run these on Symantec 1.02A on 
Win95.

Randy Heisch.


Benchmark: class file exerciser
What it does: exercises various methods in base class files (java api) 
Permission: IBM will provide permission.
Proposed: Sponser: IBM
Proposed project lead: Randy Heisch (IBM)

Benchmark: database manager
What it does: performs multiple database functions on memory resident database
Permission: IBM will provide permission.
Proposed: Sponser: IBM
Proposed project lead: Randy Heisch (IBM)

Benchmark: Si - Small Interpreter
What it does: Interprets a small C-like language including "if" and "while"
statements and expression evaluation; exercises StreamTokenizer (lexical
analysis), HashTable (symbol table lookup/management) and various java
language features.  Recursive descent interpretation.
Permission: IBM will provide permission.
Proposed: Sponser: IBM
Proposed project lead: Randy Heisch (IBM)

Benchmark: anagram generator
What it does: generates anagrams from a specified string using a 40K+ word
dictionary.
Permission: IBM will provide permission.
Proposed: Sponser: IBM
Proposed project lead: Randy Heisch (IBM)
