SPECjava development release v7

*******************
**REQUIRED READING*
*******************

To Run as Applet

   To run benchmarks in the GUI harness with a web browser or
   appletviewer, open SpecApplet.html either as a local file or as a
   URL from a web server. E.g.,

	appletviewer SpecApplet.html
	appletviewer http://thisserver/thislocation/SpecApplet.html

Benchmark Changes

   _201_compress
   _202_jess
   _203_linpack		Increased run time
   _204_newmst
   _205_raytrace	Increased run time
   _207_tsp
   _208_cst
   _209_db
   _210_si		Increased run time
   _211_anagram		Increased run time
   _212_gcbench		Increased run time
   _213_javac
   _214_deltablue	New*
   _215_richards_gf	New*
   _216_richards_g	New*
   _217_richards_gns	New*
   _218_richards_dna	New*
   _219_richards_dac	New*
   _220_richards_dav	New*
   _221_richards_dai	New*

   *Not integrated into this distribution archive. You must download
    this portion separately and then untar it into the specjava
    directory. (This is so you can agree not to ship the software as
    munitions to Iraq, or use it on your A/C powered laptop computer
    while in the bathtup, void where prohibited by law, etc.)

Problems

   _213_javac		Won't run from the network

*******************
**OPTIONAL READING*
*******************

CLASSPATH

   Your CLASSPATH environment variable must include this directory. The
   shrc file does that for Bourne shell or Korn shell. However, the
   benchmarks and harness still find files relative to the current
   directory, so if you're running the benchmarks as an application,
   this has to be your current working directory; so you may as well
   just have '.' in your CLASSPATH.

To Run as Application

   To run benchmarks in the GUI harness as an application:

	java SpecApplication

Saving Results

   You can mail test results to yourself using the "Report" button, and
   filling in the appropriate recipient address in the dialog box which
   appears.

Documenting the Configuration

   You can experiment with entering reporting fields describing test
   configurations by running the Config program which reads a series of
   property files similar to SPEC95's config file, and then allows you
   to edit the fields. This is not yet integrated into the GUI harness,
   and only runs as a standalone program, writing an output property
   file used by the reporting page generator.

	java spec.reporter.Config

   You can pass properties to control operation of the program, and/or
   to set configuration values, by using the command line D flags,
   e.g.

	java -Dspec.client.systemState='single user' spec.reporter.Config

Generating a Reporting Page

   You can experiment with making reporting pages by running this program

	java spec.reporter.Report

Property Files

   config.txt

   This is the file that currently controls the reports that are mailed
   by the harness. It is currently not a property file, but uses a
   custom format.  Later its' functions will be replaced by property
   files.

   props/

   This is a directory of property files which document the test
   configuration.  They are read in a priority sequence starting from
   more general defaults and ending with more specific overriding
   values. The order is:

   spec		Sets initial defaults such as where to find the applicable
   		property files
   [dialogue]	Optional interactive editing of those defaults as to allow
   		different client or server files to be selected
   <OS.arch>	Based on your client's operating system and architecture,
   		this selects a file that will be defined by a SPEC
   		member vendor
   <vendor>	Optional native methods that can run vendor-specific
   		commands on the client to determine additional configuration
   		values such as the clock speed and cache organization
   <client>	File specified by the benchmarker to fill in as many
   		configuration values as desired for a particular client
   		platform to minimize need for retyping values from run
   		to run, describing client configuration.
   <server>	File specified by the benchmarker to fill in as many
   		configuration values as desired for a particular client
   		platform to minimize need for retyping values from run
   		to run, describing server configuration.
   [dialogue]	Optional interactive editing of all the configuration
   		properties collected thus far
   spec		Final setting of properties defined by SPEC which the
   		user is not allowed to override
   
   Some files in the props/ directory:
   
   client		an instance of a <client> file
   client.test		an instance of a <client> file
   MacOS.PPC		an instance of an <OS.arch> file
   report		Not a property file; custom format. Template
			definition of a reporting page.
   server		an instance of a <server> file
   Solaris.sparc	an instance of an <OS.arch> file
   title		defines text titles to use for properties in edit
   			dialogs and in reporting pages
