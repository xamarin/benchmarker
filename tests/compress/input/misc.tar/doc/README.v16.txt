SPECJava version 16 release notes
---------------------------------

New or Significantly Updated Benchmarks:

_200_check
    Added additional tests
_232_tomcatv
    New benchmark. Translation from FORTRAN to Java of the CPU95 version
_238_mpeg
    New benchmark. MPEG video decoding.
_239_nih
    New benchmark. Image manipulation.

