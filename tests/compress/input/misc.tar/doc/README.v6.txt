v6 development release
Fri Jun 13 08:47:55 PDT 1997

New in this release:

_212_gcbench	garbage collection benchmark from SGI. Synthetic benchmark
		stresses gc by repeatedly creating/freeing large binary
		trees.

_213_javac	Javac compiler, compiles 3 other benchmarks

install.sh	A one-line UNIX shell script for uniformity with other
		SPEC benchmarks. The actual work is done by a Java
		program you can invoke directly instead:
		   java harness.Setup
		Currently all it does is copy some source code files
		into a work directory for the javac benchmark. Later
		it can do any other installation setup actions we
		want done. It can also be hooked into the harness
