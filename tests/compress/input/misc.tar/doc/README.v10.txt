SPECJava V10
------------

This version is fairly like V9, a few minor bugs have been cleared up,
and a few new benchmarks have been added. Some of these may cause a few
problems, but we felt it better to get these in now so people could try
them out even if they do not operate perfectly.

There is a new "Help" button with which you can get context sensitive
help information.  In a browser window it's nice looking and
hyper-linked. In a console it's rather ugly and you cannot navigate
around.

The new benchmarks are:

_213_javac - This has been put back now Sun has legal clearance.

_225_shock - This computes 1-D ideal gas shock waves, and uses
2nd-Order Godunov Method Finite Difference computation (whatever that
is!).

_227_mtrt - A multi-threaded version of _205_raytrace

_228_jack - A Java parser generator that is based on the Purdue
Compiler Construction Tool Set (PCCTS). This is an early version of
what is now called JavaCC.

_300_tmix - Dining philosophers who do real thinking between bites.
From Salina & Kaivalya.

Minor bug fixes and changes
---------------------------

No long lines (>80 characters) should appear in the email.

All the richards benchmarks should verify now.

Having done this all the separate Richards benchmarks have been removed
from the 'All' group.

A 'help' system has been added.


