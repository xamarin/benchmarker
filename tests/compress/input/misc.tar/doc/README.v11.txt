SPECJava version 11 release notes
---------------------------------

New or Significantly Updated Benchmarks:

_200_check
    Added test that subclassing is allowed. I.e., the JVM doesn't
    "optimize" by assuming that all classes/methods/variables are
    final.
_202_jess
    Increased run time of 100% problem. Left original problem as 10%.
    Added shorter 1% problem.
_208_cst
    Update from IBM with improved internal validity checking and
    problem sizes.
_209_db
    Update from IBM with improved internal validity checking and
    problem sizes.
_210_si
    Update from IBM with improved internal validity checking and
    problem sizes.
_211_anagram
    Update from IBM with improved internal validity checking and
    problem sizes.
_213_javac
    -verbose option removed to reduce console output
_228_jack
    Increased run time (I hope)
_229_tsgp
    New benchmark: solves the traveling salesman problem by means of 
    genetic programming.



Notes from Nik:
    
1, Walter has done wonderful things to the user interface.

2, The console output has changed in two ways. Firstly if the property
   "spec.initial.console" is not set equal to "true" then there will be
   no console window and the console output will go to stdout.

3, Secondly no data will appear in the console window prior to the
   button being pressed for the first time. If the button is never
   pressed therefore no trace is kept and there is no growing buffer of
   data to be kept lying around wasting space.

4, A validation problem has been fixed in 228_jack where '\r'
   characters were placed in the validation buffer on WIN32 systems.

5, The v10 validity check files for db were wrong and these have been fixed.

6, All data written to files, which is thrown away, is now used to calculate a 
   checksum, and this, along with the number of characters written, is used for 
   validity checking.

7, A minor bug fix that appears to have made no difference was done to
   _205_raytrace at the author's request.

8, The -verbose option was removed from _213_javac to reduce the console output.

9, A mysterious new benchmark called _229_tsgp has appeared. It apparently does 
   something genetic to travailing salesmen.

10, _300_tmix renumbered to _231_tmix



Notes from Walter on the revamped user interface:
(let's see whether you agree this is "wonderful" or merely different):

    The window was rearranged for a size that better fit the most
    constrained screen size envisioned for the suite - a laptop computer.

    More controls have been moved to the initial screen

    The 'platform' property file has been eliminated.  This was the file
    derived from os.version and os.arch intended to be provided by SPEC
    members to fill in a few common reporting fields.  It turns out the
    naming of these values by third party software vendors is not
    consistent, and there's not much of value the vendors could put in
    anyway.  So we simplified to having just a client and a server file.

    You have an initial choice whether to do a SPEC compliant or a test run

    SPEC compliant mode disables controls which would violate run rules,
    whereas test mode allows unlimited experimentation

    More vertical space is given to the list of benchmarks so you're more
    likely to be able to see all of them (after final SPEC candidate
    selection).

    Some of the "notice" type information was moved from fixed positions as
    labels or in the html into the scrolling status window so you can read
    it one time and not have to keep looking at it.

    Some additional initial status messages are written to that window to
    explain what to do next.

    I changed the suite name to SPECjavaClient98 because I will propose
    that we should not usurp the name SPECjava98 which could indicate that
    we claimed this was representative of any type of Java computing
    whatsoever.  It seems likely that we will also have SPECjavaServer98/9
    and SPECjavaMedia98/9 suites.

    The setup window now is now off-white instead of default grey

    The setup window attempts to resize itself appropriately for the size
    of your screen.  If it fails, please report the problem, and work
    around it by setting the property spec.initial.maxRows in props/spec to
    the number of rows you want per panel on your screen.

    Fields in the setup screen are now packed together so that when there
    are only a few fields they aren't stretched across the screen.



