V9 Release notes
================

Console output window
---------------------

Use of the "standard output" has been eliminated because this could not
been seen on a number of systems. The output now appears in a console
window. Data is written to this window by calling Context.out.println()
instead of System.out.println()

Verification
------------

The data send to the console window is also used for verification. The
way this is done is governed by a set of verification rules. Each line
written to Context.out has a rule associated with it. The rules coded
thus:

    0 - The line is to be ignored.
    1 - The line must match exactly
    2 - The line must match when all numbers are removed
    3 - The line must match when all '/' and '\' characters are removed
    4 - The line must match then all numbers and `/` and '\' are removed

All benchmarks have a default verification code that is applied to all
lines written to Context.out. This is occasionally overridden (see
_223_diners for an example) but this is rarely needed. When these rules
have been applied to the output data it is then compared with a file
that contains the reference data for the benchmark and the first 50
mismatches are written into the email report.

Several of the benchmarks have been changed to write out something that
can be verified using this process. in addition the number of bytes
output by each benchmark is counted and this number is used for
verification.


Autorun rules
-------------

The autorun criteria for finishing has been changed from 5% to 2%. This
can now be altered by changing the property:

    spec.initial.percentTimes100=200

The V8 autorun bug where System.gc() was not being called between runs
has also been fixed.

Stand alone mode
---------------

This version includes the ability to run the benchmarks individually
without the harness, and in this mode no AWT classes are loaded.

The syntax to do this is:

    java SpecApplication [<switches>] <name of benchmark>

The switches are:

     -a     Do an autorun
     -n     Do no cache input data
     -s1    Do a 1% run
     -s10   Do a 10% run
     -s100  Do a 100% run (the default)
     -v     Do *not* verify

Example:

    java SpecApplication -s10 _201_compress

This mode is not intended to be used for benchmarking, only for early testing of new
JVMs in development.


Email report
------------

This now includes:

    - The state of the 1/10/100% flag.
    - The free and total space before and after each benchmark run.
    - The state of the cache enable flag.


Benchmark changes
-----------------

All benchmarks have has all references to System.out changes to Context.out, and all
awt and net code removed. Also several have had additional output added for
verification..

_205_raytrace:  At the authors request all 'final' and finalize() statements have 
                been removed.

_209_db:        Put back into 'All' group, but the 1/10/100% scaling has been 
                removed. 

_211_anagram:   Changed the input so a few anagrams are actually produced.

_213_javac:     Fixed problem where files were failing to be read because bad URLs
                were being constructed.

_222_mpegaudeo: Fixed bytecode verifier problem and included in the 'All' group

_223_diners:    New benchmark that implements the Dijkstra's Dining Philosophers 
                Problem.

_224_richards:  A combination of all the existing Richards benchmarks into one.
