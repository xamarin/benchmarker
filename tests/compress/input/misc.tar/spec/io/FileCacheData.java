package spec.io;

import java.util.*;



public class FileCacheData{

  private byte[] data = null;
  private int total_num_bytes = 0;
  
  public FileCacheData(int len){
    
    data = new byte[len];

  }
 

  public void createData(int len){
    
    data = new byte[len];

  }

  public void copyData(byte b[] , int off , int num_bytes){
    
    System.arraycopy(b,off,data,total_num_bytes, num_bytes);
    total_num_bytes += num_bytes;

  }

  public void copyData(byte b){

    data[total_num_bytes] = b;
    total_num_bytes += 1;

  }

  public void skipPos(long n){
    total_num_bytes += n;
  }

 
  public java.io.InputStream getInputStream(){

    return new java.io.ByteArrayInputStream(data , 0 , total_num_bytes);

  }

  public int getLength(){
    return total_num_bytes;
  }

}



