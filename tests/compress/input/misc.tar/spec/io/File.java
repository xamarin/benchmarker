package spec.io;

public class File extends java.io.File{

  String filename;

  private static TableOfExistingFiles tef = new TableOfExistingFiles();
  
  public File(String path){

    super(path);

    //System.out.println("Inside constructor File(" + path + ")");

    filename = path;

  }

  public File(String path , String name){

    super(path , name);

    //System.out.println("Inside constructor File(" + path + " , " + name + ")");

    filename = path + name;

  }

  public File(File dir , String name){

    super(dir , name);

    //System.out.println("Inside constructor File(dir, name) , dir.getName = " + dir.getName());

    filename = dir.getPath() + name;

  }

  public String getName(){

    String returnvalue = super.getName();

    //System.out.println("Inside File.getName() , \nfilename = " + filename + "\nreturnvalue = " +returnvalue);

    
    return returnvalue;

  }

  public String getPath(){

    String returnvalue = super.getPath();
    
    //System.out.println("Inside File.getPath() ,  filename = " + filename + " returnvalue = " +returnvalue);

    return returnvalue;

  }

  public String getAbsolutePath(){

    String returnvalue = super.getAbsolutePath();
   
    //System.out.println("Inside File.getAbsolutePath() ,  filename = " + filename + " returnvalue = " + returnvalue);

    return returnvalue;

  }

  public String getParent(){

    String returnvalue = super.getParent();

    //String returnvalue = null;

    //System.out.println("Inside File.getParent() ,  filename = " + filename + " returnvalue = " + returnvalue);

    return returnvalue;

  }

  public boolean exists(){

    //boolean returnvalue = super.exists();
    
    boolean returnvalue = tef.exists( filename.replace( '\\', '/' ) );

    //System.out.println("Inside File.exists() ,  filename = " + filename + " returnvalue = " + returnvalue);

    return returnvalue;

  }

  
  public boolean canWrite(){
    
    boolean returnvalue = super.canWrite();

    //System.out.println("Inside File.canWrite() ,  filename = " + filename + " returnvalue = " + returnvalue);

    return returnvalue;

  }

  
  public boolean canRead(){
    
    boolean returnvalue = super.canRead();

    //System.out.println("Inside File.canRead() ,  filename = " + filename + " returnvalue = " + returnvalue);

    return returnvalue;

  }  

  public boolean isFile(){
   
    //boolean returnvalue = super.isFile();

    boolean returnvalue = filename.endsWith("classes.zip");

    //System.out.println("Inside File.isFile() ,  filename = " + filename + " returnvalue = " + returnvalue);

    return returnvalue;

  }  


  public boolean isDirectory(){
    
    boolean returnvalue = super.isDirectory();

    //System.out.println("Inside File.isDirectory() ,  filename = " + filename + " returnvalue = " + returnvalue);

    return returnvalue;

  }

  public long lastModified(){

    long returnvalue = super.lastModified();
    
    //System.out.println("Inside File.lastModified() ,  filename = " + filename + " returnvalue = " + returnvalue);

    return returnvalue;

  }

  public long length(){
    
    long returnvalue = super.length();

    //System.out.println("Inside File.length() ,  filename = " + filename + " returnvalue = " + returnvalue);

    return returnvalue;

  }

  public boolean mkdir(){

    boolean returnvalue = super.mkdir();

    //System.out.println("Inside File.mkdir() ,  filename = " + filename + " returnvalue = " + returnvalue);

    return returnvalue;

  }

  public boolean renameTo(File dest){

    boolean returnvalue = super.renameTo(dest);

    //System.out.println("Inside File.renameTo() ,  filename = " + filename +  " returnvalue = " + returnvalue);

    return returnvalue;

  }

  public boolean mkdirs() {

    boolean returnvalue = super.mkdirs();

    //System.out.println("Inside File.mkdirs() ,  filename = " + filename +  " returnvalue = " + returnvalue);

    return returnvalue;

  }

  public String[] list(){
 
    String[] returnvalue = super.list();
    
    //System.out.println("Inside File.list() ,  filename = " + filename +  " returnvalue = " + returnvalue);

    return returnvalue;

  }

  public String[] list(java.io.FilenameFilter filter){
 
    String[] returnvalue = super.list(filter);

    //System.out.println("Inside File.list(filter) ,  filename = " + filename +  " returnvalue = " + returnvalue);

    return returnvalue;

  }

  public boolean delete(){

    boolean returnvalue = super.delete();

    //System.out.println("Inside File.delete() ,  filename = " + filename +  " returnvalue = " + returnvalue);
    
    return returnvalue;

  }

  public int hashCode(){

    int returnvalue = super.hashCode();

    //System.out.println("Inside File.hashcode() ,  filename = " + filename +    " returnvalue = " + returnvalue);

    return returnvalue;

  }

  public boolean equals(Object obj){

    boolean returnvalue = super.equals(obj);

    //System.out.println("Inside File.equals() ,  filename = " + filename +  " returnvalue = " + returnvalue);

    return returnvalue;
  }

  
  public String toString(){

    String returnvalue = super.toString();

    //System.out.println("Inside File.toString() ,  filename = " + filename +  " returnvalue = " + returnvalue);

    return returnvalue;

  }

}
    
    
    
    
  
    
