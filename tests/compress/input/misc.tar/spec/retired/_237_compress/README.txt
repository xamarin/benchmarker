Date: Mon, 24 Nov 1997 15:53:06 -0500
From: Anne Troop <amt@fpk.hp.com>
Subject: _201_compress/Harness.java

Hi Walter,

Here's a modified Harness.java for compress to cause it to cycle
through 26 different start_char's.  Since creating the input
takes time, I readjusted the loop count from 25 to 12.  Thus,
any given seed will be used 1200/26 == about 50 times, instead
of 2500.  And it's only 3 lines of code change.  I expect
I've missed the cutoff for v15.  Hopefully it won't cause too
much extra churn in v16.

Whimsy,
Anne
1c1,8
< // SPEC development version @(#)Harness.java	1.7 97/08/04
---
> // SPEC development version %W% %G%
> // Based on _201_compress @(#)Harness.java	1.7 97/08/04
> // Here's a modified Harness.java for compress to cause it to cycle
> // through 26 different start_char's.  Since creating the input
> // takes time, I readjusted the loop count from 25 to 12.  Thus,
> // any given seed will be used 1200/26 == about 50 times, instead
> // of 2500.  And it's only 3 lines of code change.
> // 	Anne Troop <amt@fpk.hp.com>
3c10
< package spec.benchmarks._201_compress;
---
> package spec.benchmarks._237_compress;
883a891,892
> 	for (i = 1; i <= 12; i++) {
> 	start_char = (byte)((int)start_char + 1);
885d893
< 	for (i = 1; i <= 25; i++) {
919a928
> 
