package spec.benchmarks._237_compress;
import spec.harness.*;

public class Main implements SpecBenchmark {


    static long runBenchmark( String[] args ) {
    
        if( args.length == 0 ) {
            args = new String[3];
	    args[0] = "10000";
    	    args[1] = "abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz";
	    args[2] = "31";
	}
	
	return new Harness().inst_main( args );
    }


    public static void main( String[] args ) {  	 
        runBenchmark( args );
    }

    
    public long harnessMain( String[] args ) {
        return runBenchmark( args );
    }

  
}
