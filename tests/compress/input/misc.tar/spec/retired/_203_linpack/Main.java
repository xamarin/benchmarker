package spec.benchmarks._203_linpack;
import spec.harness.*;


public class Main implements SpecBenchmark {

    static long runBenchmark( String[] args ) {
	return new Linpack().inst_main( args );
    }

    public static void main( String[] args ) {  	 
        runBenchmark( args );
    }

    public long harnessMain( String[] args ) {
        return runBenchmark( args );
    }

}
