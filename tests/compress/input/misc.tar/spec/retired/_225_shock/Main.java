package spec.benchmarks._225_shock;
import spec.harness.*;


public class Main implements SpecBenchmark {


    static long runBenchmark( String[] args ) {    		
	Shock1DNG.main( args );
	return 0;
    }


    public static void main( String[] args ) {  	 
        runBenchmark( args );
    }

    
    public long harnessMain( String[] args ) {
        return runBenchmark( args );
    }

  
}
