SHOCK1D README PAGES
-----------------------------------------------------------
Introduction:

Shock1D is a simple shockwave solver for 1D ideal gas problems.
The solution uses a 2nd-Order Godunov Scheme (Colella et al. 1984)
implemented as a Riemann Solver.

What is special about this version is the use of Java and Threads
to compute this problem.  This is purely done as a test and demonstration
of Java's Threading, GUI, and Computational ability.  It does not
try to show that Java can compare to FORTRAN native performance.

-James Liu, Ph.D., Dept of Nuclear Engineering, UC Berkeley
-----------------------------------------------------------
Instructions:

Get a Java VM. 1.1.x  A recent version is preferred
because it maps Threads to native OS Threads and can take
advantage of MP. 

On the UNIX command line, type:

	% java Shock1D

Everything else should be pretty intuitive.

For running under non-GUI environments, you can execute this
standalone by typing:

	%java Shock1DNG

-----------------------------------------------------------
Description of the Problem:

Shock1D is a shockwave solver.  A shockwave in physics, can be
defined as a discontinuity in pressure across an infinitesmally
thin interface.  Across the interface, flow of mass, momentum
and energy are conserverd.

The standard numerical solution technique used to solve this type
of problem is to use Time-Dependent Upwind Finite Differencing.  
Standard Upwind techniques which apply to continuum flows with real
1st, 2nd and higher-order derivatives do not work well.  A shock
can be considered a mathematical discontinuity and therefore,
has a non-real 1st derivative.

The numerical techniques for these types of shock problems belong to 
a class of Finite Difference solvers that incorporate artificial
viscosity and change in order of accuracy depending on the flow
conditions.  In other words, near shock discontinuities, the scheme
is lower-order of accuracy, and in smooth regions, the scheme reverts
to higher-order.  These schemes are often Total Variation Diminishing
in time.  In our ideal shock problem, TVD implies that the solution
over time, should converge to the ideal shock/rarefaction solution
predicted analytically in Riemann's Problem.

-----------------------------------------------------------
What Shock1D shows:

The Java application described here, does the following things

	1.  splits the 1D space into multiple cells
	2.  assigns initial conditions to each cell
	3.  uses what's in the trade called a "Riemann Solver"
	    to compute flux of mass, momentum and energy
            from cell to cell.
	4.  increments a time-step, then repeats itself

The graphic visualization is a colormap of logarithmic density
and how it varies with time.  The vertical axis is the time
and the horizontal is the position.  The "fan"-shaped pictures
you will see represent the "characteristic" lines of the wave
flow.  Sharp discontinuities in density are shocks (compression
waves), while gradients represent rarefactions (i.e. expanision
waves).
-----------------------------------------------------------
Boundary and Initial Conditions:

In this problem, Shock1D assumes rigid boundary conditions.
This means shocks and rarefactions will reflect from walls.

We use non-dimensional units.  Since this is an upwind 
explicit method, the Courant condition C < 1.0 is applied.
We tend to increment timesteps based on estimates of C=0.9.
This appears stable except for the most severe of shock
reflections.  In the high shock reflection states where C >= 1
the computational kernel discards the new computation, lowers
the timestep value and re-iterates the computational sweep
for a small convective quantity.
-----------------------------------------------------------
