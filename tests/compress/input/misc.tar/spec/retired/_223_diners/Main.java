
package spec.benchmarks._223_diners;
import spec.harness.*;


public class Main implements SpecBenchmark {

    static long runBenchmark( String[] args ) {
	DiningPhilosophersProblem.run(spec.harness.Context.getSpeed()*8000);
	return 0; 
    }

    public static void main(String[] args) {  	 
        runBenchmark(args);
    }
    
    public long harnessMain(String[] args) {
        return runBenchmark(args);
    }
}