package spec.benchmarks._210_si;
import spec.harness.*;

public class Main implements SpecBenchmark {

    static long runBenchmark( String[] args ) {
    
	String name = "refspeed1.si";
	int speed = spec.harness.Context.getSpeed();
    
	if( speed > 1 )
	    name = "refspeed10.si";	

	if( speed > 10 )
	    name = "refspeed100.si";	
    
	    
        if( args.length == 0 ) {
	    args = new String[1];
	    args[0] = "input/"+name;
	}
	
	long time = 0;
	
	do {
	    time += new Si().inst_main( args );
	    speed = speed - 100;
	} while( speed >0 );
	
	return time;
    }


    public static void main( String[] args ) {  	 
        runBenchmark( args );
    }

    
    public long harnessMain( String[] args ) {
        return runBenchmark( args );
    }

}
