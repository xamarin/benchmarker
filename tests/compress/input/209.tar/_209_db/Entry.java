/*
 * Entry.java   Version 1.0 03/03/97 rrh
 *
 * Copyright (c) 1996 IBM Corporation, Inc. All rights reserved.
 *
 * Permission is expressly granted by IBM Corporation only for short-term and
 * limited distribution within the SPEC voting member companies for use in
 * preparation of a benchmark suite.
 *
 * Please delete all copies of this revision after a steering committee vote on
 * this benchmark is taken.
 *
 * Another revision of this source code will be provided through official SPEC
 * distribution channels if this program passes the OSSC and is to be presented
 * to the general SPEC membership for a final vote.
 *
 * This source code is provided as is, without any express or implied warranty.
 *
 *
 * Randy Heisch       IBM Corp. - Austin, TX
 *
 * SPEC development version @(#)Entry.java	1.2 10/23/97
 */
 
package spec.benchmarks._209_db;

import java.util.*;


public class Entry
   {
   Vector items;


   Entry()
      {
      items = new Vector();
      }


   public boolean equals(Object o)
      {
      Entry entry;
      Object o1, o2;

      if ( !(o instanceof Entry) )
         return false;

      entry = (Entry)o;

      if ( entry.items.size() != items.size() )
         return false;

      Enumeration e1 = items.elements();
      Enumeration e2 = entry.items.elements();

      while ( e1.hasMoreElements() )
         {
         o1 = e1.nextElement();
         o2 = e2.nextElement();

         if ( !((String)o1).equals(((String)o2)) )
            return false;
         }

      return true;
      }



   public int hashCode()
      {
      int hc = 0;
      String s;

      Enumeration e1 = items.elements();

      while ( e1.hasMoreElements() )
         {
         s = (String)e1.nextElement();

         hc += s.hashCode();
         }

      return hc;
      }



   }


