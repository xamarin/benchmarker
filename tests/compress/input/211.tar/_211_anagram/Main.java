// Last update 02/18/98 kaivalya -- added workload
// Last update 10/21/97, Kaivalya/Salina
// SPEC development version %W% %G%

package spec.benchmarks._211_anagram;
import spec.harness.*;

public class Main implements SpecBenchmark {

    static long runBenchmark( String[] args ) {
    
	int speed = spec.harness.Context.getSpeed();
    
        if ( args.length == 0 ) {
	    if( speed == 1 ) {
		args = new String[6];
		args[0] = "input/dict1.mid";
		args[1]  = "break";
   		args[2]  = "march"; 
   		args[3]  = "peach"; 
   		args[4]  = "quite"; 
   		args[5]  = "regal"; 
	    } 

	    if( speed == 10 ) {
		args = new String[11];
		args[0] = "input/dict1.mid";
		args[1]  = "break";
   		args[2]  = "march"; 
   		args[3]  = "peach"; 
   		args[4]  = "quite"; 
   		args[5]  = "regal"; 
   		args[6]  = "fetish";
   		args[7]  = "ruffian"; 
   		args[8]  = "hamlet";
   		args[9]  = "credit"; 
   		args[10] = "agree"; 
	    }
	    
	       if ( speed == 100) {
		args = new String[64];   // kmd 2/18
		args[0]  = "input/dict1";
		args[1]  = "break";
   		args[2]  = "march"; 
   		args[3]  = "peach"; 
   		args[4]  = "quite"; 
   		args[5]  = "regal"; 
   		args[6]  = "fetish";
   		args[7]  = "ruffian"; 
   		args[8]  = "hamlet";
   		args[9]  = "credit"; 
   		args[10] = "agree"; 
   		args[11] = "spoon"; 
   		args[12] = "ribald"; 
   		args[13] = "process"; 
   		args[14] = "despot"; 
   		args[15] = "abduct"; 
   		args[16] = "redact"; 
   		args[17] = "lamp";
   		args[18] = "meal";
   		args[19] = "sale";
   		args[20] = "cream";
   		args[21] = "relatives";
   		args[22] = "masculine";
   		args[23] = "selector";
   		args[24] = "hikers";
   		args[25] = "belong";
   		args[26] = "bizarre";
   		args[27] = "postage";
   		args[28] = "hurricane";
   		args[29] = "hustle";
   		args[30] = "slimiest";
   		args[31] = "strudel";
   		args[32] = "dilatory";
   		args[33] = "sedative";
   		args[34] = "lethal";
   		args[35] = "green";
   		args[36] = "ripostes";
   		args[37] = "supersonic";
   		args[38] = "porter";
   		args[39] = "competitor";
   		args[40] = "ulcer";
   		args[41] = "angered";
   		args[42] = "trout";
   		args[43] = "robe";
   		args[44] = "inspire";
   		args[45] = "tailspin";
   		args[46] = "utopia";
   		args[47] = "moues";
   		args[48] = "fondu";
   		args[49] = "desert";
   		args[50] = "risque";
   		args[51] = "patcher";
   		args[52] = "phoney";
   		args[53] = "bore";
   		args[54] = "patching";
   		args[55] = "lamenting";
   		args[56] = "tire";
   		args[57] = "anagram";
   		args[58] = "cowherd";
   		args[59] = "trees";
   		args[60] = "metric";
   		args[61] = "tramline";
   		args[62] = "trijet";
   		args[63] = "testee";
	    }
	}
	
	return new anagram().inst_main( args );
    }


    public static void main( String[] args ) {  	 
        runBenchmark( args );
    }

    
    public long harnessMain( String[] args ) {
        return runBenchmark( args );
    }

  
}

