/*
 * ObjNode.java
 *
 * Copyright (c) 1996 Sun Microsystems, Inc. All rights reserved.
 *
 * Permission is expressly granted by Sun Microsystems only for short-term and
 * limited distribution within the SPEC voting member companies for use in
 * preparation of a benchmark suite.
 * 
 * Please delete all copies of this revision after a steering committee vote on
 * this benchmark is taken.
 * 
 * Another revision of this source code will be provided through official SPEC
 * distribution channels if this program passes the OSSC and is to be presented
 * to the general SPEC membership for a final vote.
 * 
 * This source code is provided as is, without any express or implied warranty.
 *
 *
 * A linked list node of objects.
 *
 */
package spec.benchmarks._205_raytrace;
//import LinkNode;
//import ObjectType;

/**
 * class ObjNode
 */
public class ObjNode extends LinkNode {
    private ObjectType theObject;

    /**
     * ObjNode
     */
    public
    ObjNode() {
	super(null);
	theObject=null;

    }

    /**
     * ObjNode
     * @param newObj
     * @param nextlink
     */
    public
    ObjNode(ObjectType newObj, LinkNode nextlink) {
	super(nextlink);
	theObject=newObj;

    }

    /**
     * Next
     * @return ObjNode
     */
    public
    ObjNode Next() { 

	 return ((ObjNode) GetNext());
    }

    /**
     * GetObj
     * @return ObjectType
     */
    public
    ObjectType GetObj() { 

	 return (theObject);
    }

};
