/*
 * CacheIntersectPt.java
 *
 * Copyright (c) 1996 Sun Microsystems, Inc. All rights reserved.
 *
 * Permission is expressly granted by Sun Microsystems only for short-term and
 * limited distribution within the SPEC voting member companies for use in
 * preparation of a benchmark suite.
 * 
 * Please delete all copies of this revision after a steering committee vote on
 * this benchmark is taken.
 * 
 * Another revision of this source code will be provided through official SPEC
 * distribution channels if this program passes the OSSC and is to be presented
 * to the general SPEC membership for a final vote.
 * 
 * This source code is provided as is, without any express or implied warranty.
 *
 *
 * Caches the intersection point of a ray with an object.
 *
 */
package spec.benchmarks._205_raytrace;
//import IntersectPt;

/**
 * class CacheIntersectPt
 */
public class CacheIntersectPt extends IntersectPt {
    private int RayID;

    /**
     * CacheIntersectPt
     */
    public
    CacheIntersectPt() { 
	
	RayID=0;

    }

    /**
     * GetID
     * @return int
     */
    public
    int GetID() { 

	 return (RayID);
    }

    /**
     * Set
     * @param newID
     * @param newIntersect
     */
    public 
    void Set(int newID, IntersectPt newIntersect) { 

	 RayID = newID;
	 SetIsectPt(newIntersect);
    }

};

