package spec.benchmarks._205_raytrace;
import spec.harness.*;


public class Main implements SpecBenchmark {


    static long runBenchmark( String[] args ) {
    
        if( args.length == 0 ) {
   	    args = new String[3];	    
	    args[0] = "" + (200*spec.harness.Context.getSpeed())/100;
	    args[1] = "200";		    
	    args[2] = "input/time-test.model";
	}
	
	return new RayTracer().inst_main( args );
    }


    public static void main( String[] args ) {  	 
        runBenchmark( args );
    }

    
    public long harnessMain( String[] args ) {
        return runBenchmark( args );
    }

  
}
