/*
 * Ray.java
 *
 * Copyright (c) 1996 Sun Microsystems, Inc. All rights reserved.
 *
 * Permission is expressly granted by Sun Microsystems only for short-term and
 * limited distribution within the SPEC voting member companies for use in
 * preparation of a benchmark suite.
 * 
 * Please delete all copies of this revision after a steering committee vote on
 * this benchmark is taken.
 * 
 * Another revision of this source code will be provided through official SPEC
 * distribution channels if this program passes the OSSC and is to be presented
 * to the general SPEC membership for a final vote.
 * 
 * This source code is provided as is, without any express or implied warranty.
 *
 *
 * Holds the ray origin and direction.
 *
 */
package spec.benchmarks._205_raytrace;
//import Point;
//import Vector;

/**
 * class Ray
 */
public class Ray  {
    Point Origin;
    Vector Direction;
    int ID;

    /**
     * Ray
     */
    public
    Ray() { 
	ID=0;
	Direction = new Vector();

    }

    /**
     * SetOrigin
     * @param neworigin
     */
    public
    void SetOrigin(Point neworigin) { 

	 Origin = neworigin;
    }

    /**
     * SetID
     * @param newID
     */
    public
    void SetID(int newID) { 

	 ID = newID;
    }

    /**
     * GetOrigin
     * @return Point
     */
    public
    Point GetOrigin() { 

	 return (Origin);
    }

    /**
     * GetDirection
     * @return Vector
     */
    public
    Vector GetDirection() { 

	 return (Direction);
    }

    /**
     * GetID
     * @return int
     */
    public
    int GetID() { 

	 return (ID);
    }

};
