/*
 * MaterialNode.java
 *
 * Copyright (c) 1996 Sun Microsystems, Inc. All rights reserved.
 *
 * Permission is expressly granted by Sun Microsystems only for short-term and
 * limited distribution within the SPEC voting member companies for use in
 * preparation of a benchmark suite.
 * 
 * Please delete all copies of this revision after a steering committee vote on
 * this benchmark is taken.
 * 
 * Another revision of this source code will be provided through official SPEC
 * distribution channels if this program passes the OSSC and is to be presented
 * to the general SPEC membership for a final vote.
 * 
 * This source code is provided as is, without any express or implied warranty.
 *
 *
 * A linked list node of materials.
 *
 */
package spec.benchmarks._205_raytrace;
//import LinkNode;
//import Material;

/**
 * class MaterialNode
 */
public class MaterialNode extends LinkNode {
    private Material theMaterial;

    /**
     * MaterialNode
     */
    public
    MaterialNode() {
	super(null);
	theMaterial=null;

    }

    /**
     * MaterialNode
     * @param newMaterial
     * @param nextlink
     */
    public
    MaterialNode(Material newMaterial, LinkNode nextlink) {
	super(nextlink);
	theMaterial=newMaterial;

    }

    /**
     * Next
     * @return MaterialNode
     */
    public
    MaterialNode Next() { 

	 return ((MaterialNode) GetNext());
    }

    /**
     * GetMaterial
     * @return Material
     */
    public
    Material GetMaterial() { 

	 return (theMaterial);
    }

};
