package spec.benchmarks._239_nih; 
import java.io.*;
import java.net.URL;

class PlugIns {

	static void install(String[] plugIns, ImageJApplet applet) {
		int nPlugIns = 0;
		for (int i=0; i<plugIns.length; i++)
			if (!plugIns[i].equals("-"))
				nPlugIns++;
		Info.showStatus("  " + nPlugIns + " plug-ins installed");
		Menus.installPlugIns(plugIns);
	}
		
		/*
		if (applet==null) {
			Info.write("Java home: " + System.getProperty("java.home"));
			Info.write("Class path: " + System.getProperty("java.class.path"));
		}
		else {
			String codeBase = applet.getDocumentBase().toString();
			Info.write("Code base: " + codeBase);
			//File dir = new File(codeBase);
			//Info.write("parent: " + dir.getParent());
			//File dir2 = new File(dir.getParent());
			//String list[] = dir.list();
			//for (int i=0; i<list.length; i++) {
			//	Info.write(list[i]);
			//}
		}
		*/
}