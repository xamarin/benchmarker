package spec.benchmarks._239_nih; 
public interface PlugIn {

	public void run(ImagePlus imp);
}