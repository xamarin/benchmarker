package spec.benchmarks._239_nih; 
import java.awt.*;

import java.applet.*;

import java.util.*;



public class ImageJApplet extends Applet {



    public void init() {

    	// Get URL of folder containing the demo images

		String imagesURL = getParameter("url");

		if (imagesURL==null)

			imagesURL = "http://rsb.info.nih.gov/ij/images/";

		

		
		// Get list of plug-ins

		String s = getParameter("plugins");

		StringTokenizer t = new StringTokenizer(s, " ");

		int nPlugIns = t.countTokens();

		String[] plugIns = new String[nPlugIns];

		for (int i = 0; i < nPlugIns; i++)

			plugIns[i] = t.nextToken();

			

		//Startup Image/J

		ImageJ ij = new ImageJ(this, imagesURL, plugIns);

    }



}

