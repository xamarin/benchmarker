package spec.benchmarks._239_nih;
import spec.harness.*;


public class Main implements SpecBenchmark {


    static long runBenchmark( String[] args) {
		
		int speed = spec.harness.Context.getSpeed();   
	    args = new String[2];
		
		args[0] = spec.harness.Context.getSpecBasePath() + "spec/benchmarks/_239_nih/Images/"; 
		//args[0] = "/c:/specjava/v17/spec/benchmarks/_239_nih/Images/"; 
		if (args[0].indexOf("http") == -1) {
			args[0] = "file://" + args[0]; 
		}
		args[1] = String.valueOf(speed); 
		
		return ImageJ.inst_main( args );
    }


    public static void main( String[] args ) {
        runBenchmark( args );
    }

    	
	public long harnessMain( String[] args ) {
		return runBenchmark( args);
    }

}

