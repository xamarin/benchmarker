package spec.benchmarks._239_nih; 
// 8-bit image statistics, including histogram

class ByteStatistics extends ImageStatistics {

	ByteStatistics(ImageProcessor ip) {
		ByteProcessor bp = (ByteProcessor)ip;
		histogram = bp.getHistogram();
		getMinAndMax();
		getStatistics();
	}

}