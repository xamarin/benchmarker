
// * 11/07/97 -- Kaivalya, Randy, Salina
/*
* SPEC development version %W% %G%
 */
package spec.benchmarks._208_cst;
import spec.harness.*;

public class Main implements SpecBenchmark {


    static long runBenchmark( String[] args ) {
    
	int speed = spec.harness.Context.getSpeed();
	int iter = 1;

        if( args.length == 0 ) {
	
	    if( speed == 100 ) {
	    args = new String[10];
	    args[0] = "p";
	    args[1] = "" + speed;
	    args[2] = "i";
	    args[3] = "" + iter;
  	    args[4] = "v";
  	    args[5] = "" + 0;
	    args[6] = "f";
	    args[7] = "input/nasachrn.txt";
	    args[8] = "d";
	    args[9] = "input/dict1";
	    }

	    if( speed == 10 ) {
	    args = new String[10];
	    args[0] = "p";
	    args[1] = "" + speed;
	    args[2] = "i";
	    args[3] = "" + iter;
  	    args[4] = "v";
  	    args[5] = "" + 0;
	    args[6] = "f";
	    args[7] = "input/nasachrn.txt.mid";
	    args[8] = "d";
	    args[9] = "input/dict1.mid";
	    }

	    if( speed == 1  ) {
	    args = new String[10];
	    args[0] = "p";
	    args[1] = "" + speed;
	    args[2] = "i";
	    args[3] = "" + iter;
  	    args[4] = "v";
  	    args[5] = "" + 0;
	    args[6] = "f";
	    args[7] = "input/nasachrn.txt.short";
	    args[8] = "d";
	    args[9] = "input/dict1.short";
	    }

	}
	
	return new cst().inst_main( args );
    }


    public static void main( String[] args ) {  	 
        runBenchmark( args );
    }

    
    public long harnessMain( String[] args ) {
        return runBenchmark( args );
    }

  
}
