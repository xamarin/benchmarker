/*
 * Output.java   Version 1.0 02/17/97 rrh
 *
 * Copyright (c) 1996 IBM Corporation, Inc. All rights reserved.
 *
 * Permission is expressly granted by IBM Corporation only for short-term and
 * limited distribution within the SPEC voting member companies for use in
 * preparation of a benchmark suite.
 *
 * Please delete all copies of this revision after a steering committee vote on
 * this benchmark is taken.
 *
 * Another revision of this source code will be provided through official SPEC
 * distribution channels if this program passes the OSSC and is to be presented
 * to the general SPEC membership for a final vote.
 *
 * This source code is provided as is, without any express or implied warranty.
 *
 *
 * Randy Heisch       IBM Corp. - Austin, TX
 *
 * SPEC development version @(#)Output.java	1.7 10/23/97
 */
package spec.benchmarks._208_cst;
 

import java.io.*;

public class Output
   {
   static String str;

   static // Static initializer
      {
      str = "";
      }


   public void println(String s)
      {
      str += s + "\n";
      spec.harness.Context.out.println(s);
      }

   public void println()
      {
      str += "\n";
      spec.harness.Context.out.println();
      }

   public void print(String s)
      {
      str += s;
      spec.harness.Context.out.print(s);
      }

   public String get()
      {
      return str;
      }

   public void flush()
      {
      }


   public void writeOutput()
      {
      String filename = "cst.out";
/*
      try
	 {
	 spec.io.FileOutputStream s = new spec.io.FileOutputStream(filename);
         new DataOutputStream(s).writeBytes(str);
	 s.close();
         }

      catch (IOException e)
         {
         spec.harness.Context.out.println("ERROR writing output file "+filename);
         //System.exit(1);
         };
 */
      }

   }
