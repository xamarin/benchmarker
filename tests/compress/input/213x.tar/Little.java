
public class Little{

  public static void main(String args[]){

//   spec.benchmarks._202_jess.Main.main(null);


      System.out.println("Hello World");

  }


}
